
"use strict";

let TirgoMissionActionGoal = require('./TirgoMissionActionGoal.js');
let TirgoMissionFeedback = require('./TirgoMissionFeedback.js');
let TirgoMissionActionResult = require('./TirgoMissionActionResult.js');
let TirgoMissionActionFeedback = require('./TirgoMissionActionFeedback.js');
let TirgoMissionAction = require('./TirgoMissionAction.js');
let TirgoMissionResult = require('./TirgoMissionResult.js');
let TirgoMissionGoal = require('./TirgoMissionGoal.js');

module.exports = {
  TirgoMissionActionGoal: TirgoMissionActionGoal,
  TirgoMissionFeedback: TirgoMissionFeedback,
  TirgoMissionActionResult: TirgoMissionActionResult,
  TirgoMissionActionFeedback: TirgoMissionActionFeedback,
  TirgoMissionAction: TirgoMissionAction,
  TirgoMissionResult: TirgoMissionResult,
  TirgoMissionGoal: TirgoMissionGoal,
};
