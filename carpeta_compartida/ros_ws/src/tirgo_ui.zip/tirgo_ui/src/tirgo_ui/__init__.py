"""Paquete Flask modular de TirGoPharma (ROS 1)."""
