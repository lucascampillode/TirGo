# tirgo_ui/src/tirgo_ui/storage_mongo.py
import os, hashlib, time
from typing import Optional, Dict, Any, List
from bson import ObjectId
from .mongo_client import get_db
from .config import PEPPER  # seguimos usando tu PEPPER para hash DNI

# ======= Utils ===============================================================
def h_dni(dni: str) -> str:
    dni = (dni or '').strip().upper()
    raw = dni + PEPPER
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

# ======= Init: índices y datos demo =========================================
def init_db_if_needed():
    db = get_db()
    # Índices (idempotentes)
    db.pacientes.create_index([("dni_hash", 1)], unique=True)
    db.medicamentos.create_index([("nombre", 1)], unique=True)
    db.recetas.create_index([("paciente_id", 1), ("medicamento_id", 1), ("activa", 1)])
    # Blindaje para no duplicar recetas activas del mismo par:
    try:
        db.recetas.create_index(
            [("paciente_id", 1), ("medicamento_id", 1)],
            unique=True,
            partialFilterExpression={"activa": True},
            name="uniq_activa_paciente_medicamento"
        )
    except Exception:
        pass

    # Semillas demo (solo si no existen)
    if db.medicamentos.estimated_document_count() == 0:
        db.medicamentos.insert_many([
            {"nombre": "Paracetamol 1g",   "requiere_receta": False, "tipo": "A", "bin_id": 1},
            {"nombre": "Ibuprofeno 400",   "requiere_receta": False, "tipo": "B", "bin_id": 2},
            {"nombre": "Vitamina C 1g",    "requiere_receta": False, "tipo": "C", "bin_id": 3},
            {"nombre": "Antibiótico RX",   "requiere_receta": True,  "tipo": "R", "bin_id": 4},
        ])
        # stock embebido en colección 'stock' para compatibilidad con tu API actual
        meds = {m["nombre"]: m["_id"] for m in db.medicamentos.find({}, {"_id":1,"nombre":1})}
        db.stock.insert_many([
            {"medicamento_id": meds["Paracetamol 1g"], "qty": 5},
            {"medicamento_id": meds["Ibuprofeno 400"], "qty": 4},
            {"medicamento_id": meds["Vitamina C 1g"],  "qty": 3},
            {"medicamento_id": meds["Antibiótico RX"], "qty": 2},
        ])

# ======= API pública equivalente a storage.py ================================

def find_or_create_paciente(nombre: str, apellidos: str, dni: str) -> Optional[str]:
    """Devuelve el _id (str) del paciente."""
    if not (nombre and apellidos and dni): return None
    db = get_db()
    dni_hash = h_dni(dni)
    doc = db.pacientes.find_one({"dni_hash": dni_hash}, {"_id": 1})
    if doc:
        return str(doc["_id"])
    res = db.pacientes.insert_one({
        "dni_hash": dni_hash,
        "nombre": nombre.strip(),
        "apellidos": apellidos.strip(),
        "necesita_restringido": False
    })
    return str(res.inserted_id)

def lookup_medicamento_by_name(name: str) -> Optional[Dict[str, Any]]:
    db = get_db()
    m = db.medicamentos.find_one({"nombre": {"$regex": f"^{name.strip()}$", "$options": "i"}})
    return m  # devuelve dict Mongo (usa m["_id"], m["tipo"], etc.)

def get_stock(med_id: Any) -> int:
    """med_id puede ser int textual o ObjectId/str; normalizamos a ObjectId."""
    db = get_db()
    oid = ObjectId(med_id) if not isinstance(med_id, ObjectId) else med_id
    s = db.stock.find_one({"medicamento_id": oid}, {"qty": 1})
    return int(s["qty"]) if s and "qty" in s else 0

def dec_stock_if_available(med_id: Any) -> bool:
    """Decrementa stock si >0, atómico."""
    db = get_db()
    oid = ObjectId(med_id) if not isinstance(med_id, ObjectId) else med_id
    res = db.stock.update_one({"medicamento_id": oid, "qty": {"$gt": 0}},
                              {"$inc": {"qty": -1}})
    return res.modified_count == 1

def permitted_meds_for_patient(paciente_id: Any) -> List[Dict[str, Any]]:
    """
    Devuelve lista de medicamentos disponibles según reglas:
    - stock.qty > 0
    - si tipo == 'R' requiere receta activa o paciente.necesita_restringido == True
    """
    db = get_db()
    pid = ObjectId(paciente_id) if not isinstance(paciente_id, ObjectId) else paciente_id

    # traemos flag del paciente
    p = db.pacientes.find_one({"_id": pid}, {"necesita_restringido": 1})
    if not p: return []

    # agregación para traer meds + stock + receta activa
    pipeline = [
        {"$lookup": {
            "from": "stock",
            "localField": "_id",
            "foreignField": "medicamento_id",
            "as": "stk"
        }},
        {"$unwind": {"path": "$stk", "preserveNullAndEmptyArrays": True}},
        {"$addFields": {"qty": {"$ifNull": ["$stk.qty", 0]}}},
        {"$lookup": {
            "from": "recetas",
            "let": {"mid": "$_id"},
            "pipeline": [
                {"$match": {
                    "$expr": {
                        "$and": [
                            {"$eq": ["$paciente_id", pid]},
                            {"$eq": ["$medicamento_id", "$$mid"]},
                            {"$eq": ["$activa", True]}
                        ]
                    }
                }},
                {"$limit": 1}
            ],
            "as": "rec_activa"
        }},
        {"$addFields": {"tiene_receta": {"$gt": [{"$size": "$rec_activa"}, 0]}}},
        {"$match": {
            "qty": {"$gt": 0},
            "$or": [
                {"tipo": {"$ne": "R"}},
                {"tiene_receta": True},
                {"$expr": {"$eq": [p.get("necesita_restringido", False), True]}}
            ]
        }},
        {"$project": {"stk": 0, "rec_activa": 0}},
        {"$sort": {"nombre": 1}}
    ]
    return list(db.medicamentos.aggregate(pipeline))

def log_dispense(med_id: Any, dni_hash: Optional[str], estado: str, detalle: str):
    db = get_db()
    oid = ObjectId(med_id) if not isinstance(med_id, ObjectId) else med_id
    db.logs.insert_one({
        "ts": int(time.time()),
        "evento": "dispense",
        "dni_hash": dni_hash,
        "med_id": oid,
        "estado": estado,
        "detalle": detalle
    })
