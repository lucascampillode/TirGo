# tirgo_ui/src/tirgo_ui/mongo_client.py
import os
from pymongo import MongoClient

def get_client():
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise RuntimeError("MONGO_URI no está definido")
    return MongoClient(uri, serverSelectionTimeoutMS=2000)

def get_db():
    c = get_client()
    return c.get_database()  # si URI es .../tirgo?... devuelve 'tirgo'
